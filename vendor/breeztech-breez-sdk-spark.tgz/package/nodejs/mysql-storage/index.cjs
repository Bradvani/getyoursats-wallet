/**
 * CommonJS implementation for Node.js MySQL Storage.
 *
 * Mirrors `postgres-storage/index.cjs` for MySQL 8.0+. SQL translation rules:
 * - `$N` placeholders → `?`
 * - `JSONB` operators (`::jsonb->>`, `@>`) → `JSON_EXTRACT`/`JSON_UNQUOTE`/`JSON_CONTAINS`
 * - `ON CONFLICT (col) DO UPDATE SET col = EXCLUDED.col` →
 *     `ON DUPLICATE KEY UPDATE col = VALUES(col)`
 * - `ON CONFLICT DO NOTHING` → `INSERT … ON DUPLICATE KEY UPDATE <pk> = <pk>`
 *   (avoid `INSERT IGNORE`: it silently swallows non-PK errors too)
 * - `pg`'s `pool.query(sql, params)` returns `{ rows, rowCount }`; mysql2's
 *   `pool.query(sql, params)` returns `[rows, fields]` for SELECT and
 *   `[okPacket, fields]` (with `affectedRows`) for write operations.
 * - Reserved words like `key` need backtick quoting in MySQL.
 * - `pool.connect()` → `pool.getConnection()`; `client.query("BEGIN")`/COMMIT/ROLLBACK
 *   → `conn.beginTransaction()`/`conn.commit()`/`conn.rollback()`.
 */

const crypto = require("crypto");

let mysql;
try {
  const mainModule = require.main;
  if (mainModule) {
    mysql = mainModule.require("mysql2/promise");
  } else {
    mysql = require("mysql2/promise");
  }
} catch (error) {
  try {
    mysql = require("mysql2/promise");
  } catch (fallbackError) {
    const loadError = new Error(
      `mysql2 not found. Please install it in your project: npm install mysql2@^3.11.0\n` +
        `Original error: ${error.message}\nFallback error: ${fallbackError.message}`
    );
    loadError.code = fallbackError.code;
    throw loadError;
  }
}

const { StorageError } = require("./errors.cjs");
const { MysqlMigrationManager } = require("./migrations.cjs");

// JSON has no BigInt, so u128 amounts are stored as decimal strings, which the
// SDK reads back as BigInts.
function toJson(value) {
  return JSON.stringify(value, (_key, v) =>
    typeof v === "bigint" ? v.toString() : v
  );
}

const PAYMENT_UPDATE_LOCK_TIMEOUT_SECS = 10;

/**
 * Base query for payment lookups. All columns are accessed by name in _rowToPayment.
 * parent_payment_id is only used by getPaymentsByParentIds.
 */
const SELECT_PAYMENT_SQL = `
    SELECT p.id,
           p.payment_type,
           p.status,
           p.amount,
           p.fees,
           p.timestamp,
           p.method,
           p.withdraw_tx_id,
           pd.tx_id AS deposit_tx_id,
           pd.vout AS deposit_vout,
           p.spark,
           l.invoice AS lightning_invoice,
           l.payment_hash AS lightning_payment_hash,
           l.destination_pubkey AS lightning_destination_pubkey,
           COALESCE(l.description, pm.lnurl_description) AS lightning_description,
           l.preimage AS lightning_preimage,
           l.htlc_status AS lightning_htlc_status,
           l.htlc_expiry_time AS lightning_htlc_expiry_time,
           pm.lnurl_pay_info,
           pm.lnurl_withdraw_info,
           pm.conversion_info,
           pm.conversion_status,
           t.metadata AS token_metadata,
           t.tx_hash AS token_tx_hash,
           t.tx_type AS token_tx_type,
           t.invoice_details AS token_invoice_details,
           s.invoice_details AS spark_invoice_details,
           s.htlc_details AS spark_htlc_details,
           lrm.nostr_zap_request AS lnurl_nostr_zap_request,
           lrm.nostr_zap_receipt AS lnurl_nostr_zap_receipt,
           lrm.sender_comment AS lnurl_sender_comment,
           lrm.payment_hash AS lnurl_payment_hash,
           pm.parent_payment_id
      FROM brz_payments p
      LEFT JOIN brz_payment_details_lightning l ON p.id = l.payment_id AND p.user_id = l.user_id
      LEFT JOIN brz_payment_details_token t ON p.id = t.payment_id AND p.user_id = t.user_id
      LEFT JOIN brz_payment_details_spark s ON p.id = s.payment_id AND p.user_id = s.user_id
      LEFT JOIN brz_payment_details_deposit pd ON p.id = pd.payment_id AND p.user_id = pd.user_id
      LEFT JOIN brz_payment_metadata pm ON p.id = pm.payment_id AND p.user_id = pm.user_id
      LEFT JOIN brz_lnurl_receive_metadata lrm ON l.payment_hash = lrm.payment_hash AND l.user_id = lrm.user_id`;

/**
 * mysql2 may return JSON columns as either parsed objects or raw strings
 * depending on driver/server behavior. This helper normalizes both shapes.
 */
function parseJson(value) {
  if (value == null) return null;
  if (typeof value === "string") return JSON.parse(value);
  return value;
}

/** Normalize MySQL's TINYINT(1) to a JS boolean. */
function toBool(value) {
  if (value == null) return null;
  if (typeof value === "boolean") return value;
  return value === 1 || value === "1" || value === true;
}

/**
 * Maps a brz_cross_chain_swaps row to the camelCase StoredCrossChainSwap shape
 * the SDK expects, coercing TINYINT(1) to a boolean.
 */
function crossChainSwapFromRow(row) {
  return {
    provider: row.provider,
    id: row.id,
    isTerminal: toBool(row.is_terminal),
    updatedAt: Number(row.updated_at),
    data: row.data,
    secrets: row.secrets,
  };
}

/**
 * A row holds a leaf recovery and one of its watchtower exit recoveries, so
 * a leaf recovery with several of them spans several rows.
 */
function leafRecoveriesFromRows(rows) {
  const leafRecoveries = [];
  for (const row of rows) {
    let leafRecovery = leafRecoveries[leafRecoveries.length - 1];
    if (leafRecovery?.leafId !== row.leaf_id) {
      leafRecovery = {
        leafId: row.leaf_id,
        chainCheckedAt:
          row.chain_checked_at != null ? BigInt(row.chain_checked_at) : null,
        watchtowerExitOutput:
          row.output_block_height != null
            ? {
                txid: row.output_txid,
                vout: Number(row.output_vout),
                amountSats: BigInt(row.output_amount_sats),
                scriptPubkey: row.output_script_pubkey,
                blockHeight: Number(row.output_block_height),
              }
            : null,
        watchtowerExitRecoveries: [],
        watchtowerExitSpend:
          row.spend_block_height != null
            ? {
                txid: row.spend_txid,
                blockHeight: Number(row.spend_block_height),
              }
            : null,
        unilateralExitSweep:
          row.sweep_block_height != null
            ? {
                txid: row.sweep_txid,
                blockHeight: Number(row.sweep_block_height),
              }
            : null,
      };
      leafRecoveries.push(leafRecovery);
    }
    if (row.recovery_txid != null) {
      leafRecovery.watchtowerExitRecoveries.push({
        txid: row.recovery_txid,
        transactionHex: row.recovery_transaction_hex,
        outputAmountSats: BigInt(row.recovery_output_amount_sats),
      });
    }
  }
  return leafRecoveries;
}

class MysqlStorage {
  /**
   * @param {import('mysql2/promise').Pool} pool - Connection pool (may be shared with other tenants).
   * @param {Buffer|Uint8Array} identity - 33-byte secp256k1 compressed pubkey
   *   uniquely identifying this tenant. All reads and writes are scoped to it
   *   so that multiple instances with distinct identities can share one DB.
   * @param {object} [logger]
   */
  constructor(pool, identity, logger = null, runMigration = true) {
    if (!identity) {
      throw new StorageError("MysqlStorage requires a tenant identity");
    }
    this.pool = pool;
    this.identity = Buffer.from(identity);
    this.logger = logger;
    this.runMigration = runMigration;
  }

  /** Initialize the database (run migrations). */
  async initialize() {
    try {
      if (this.runMigration) {
        const migrationManager = new MysqlMigrationManager(this.logger);
        await migrationManager.migrate(this.pool, this.identity);
      }
      return this;
    } catch (error) {
      throw new StorageError(
        `Failed to initialize MySQL database: ${error.message}`,
        error
      );
    }
  }

  /** Close the pool. */
  async close() {
    if (this.pool) {
      await this.pool.end();
      this.pool = null;
    }
  }

  /**
   * Run a function inside a transaction.
   * @param {function(import('mysql2/promise').PoolConnection): Promise<T>} fn
   * @returns {Promise<T>}
   * @template T
   */
  async _withTransaction(fn) {
    const conn = await this.pool.getConnection();
    try {
      await conn.query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
      await conn.beginTransaction();
      const result = await fn(conn);
      await conn.commit();
      return result;
    } catch (error) {
      await conn.rollback().catch(() => {});
      throw error;
    } finally {
      conn.release();
    }
  }

  // ===== Cache Operations =====

  async getCachedItem(key) {
    try {
      const [rows] = await this.pool.query(
        "SELECT value FROM brz_settings WHERE user_id = ? AND `key` = ?",
        [this.identity, key]
      );
      return rows.length > 0 ? rows[0].value : null;
    } catch (error) {
      throw new StorageError(
        `Failed to get cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  async setCachedItem(key, value) {
    try {
      await this.pool.query(
        "INSERT INTO brz_settings (user_id, `key`, value) VALUES (?, ?, ?) " +
          "ON DUPLICATE KEY UPDATE value = VALUES(value)",
        [this.identity, key, value]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  async deleteCachedItem(key) {
    try {
      await this.pool.query(
        "DELETE FROM brz_settings WHERE user_id = ? AND `key` = ?",
        [this.identity, key]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete cached item '${key}': ${error.message}`,
        error
      );
    }
  }

  // ===== Payment Operations =====

  async listPayments(request) {
    try {
      const actualOffset = request.offset != null ? request.offset : 0;
      const actualLimit =
        request.limit != null ? request.limit : 4294967295;

      // Tenant scoping is always the first WHERE clause; subsequent dynamic
      // filters add more clauses and parameters.
      const whereClauses = ["p.user_id = ?"];
      const params = [this.identity];

      if (request.typeFilter && request.typeFilter.length > 0) {
        const placeholders = request.typeFilter.map(() => "?");
        whereClauses.push(
          `p.payment_type IN (${placeholders.join(", ")})`
        );
        params.push(...request.typeFilter);
      }

      if (request.statusFilter && request.statusFilter.length > 0) {
        const placeholders = request.statusFilter.map(() => "?");
        whereClauses.push(`p.status IN (${placeholders.join(", ")})`);
        params.push(...request.statusFilter);
      }

      if (request.fromTimestamp != null) {
        whereClauses.push("p.timestamp >= ?");
        params.push(request.fromTimestamp);
      }

      if (request.toTimestamp != null) {
        whereClauses.push("p.timestamp < ?");
        params.push(request.toTimestamp);
      }

      if (
        request.paymentDetailsFilter &&
        request.paymentDetailsFilter.length > 0
      ) {
        const allPaymentDetailsClauses = [];
        for (const paymentDetailsFilter of request.paymentDetailsFilter) {
          const paymentDetailsClauses = [];

          // Base type check: ensure payment type matches the filter type.
          // Token payments are identified by spark = NULL AND a token row
          // joined in via t.tx_hash.
          if (paymentDetailsFilter.type === "spark") {
            paymentDetailsClauses.push("p.spark = 1");
          } else if (paymentDetailsFilter.type === "token") {
            paymentDetailsClauses.push("p.spark IS NULL AND t.tx_hash IS NOT NULL");
          } else if (paymentDetailsFilter.type === "lightning") {
            paymentDetailsClauses.push("l.htlc_status IS NOT NULL");
          }

          const htlcAlias =
            paymentDetailsFilter.type === "spark"
              ? "s"
              : paymentDetailsFilter.type === "lightning"
                ? "l"
                : null;
          if (
            htlcAlias &&
            paymentDetailsFilter.htlcStatus !== undefined &&
            paymentDetailsFilter.htlcStatus.length > 0
          ) {
            const placeholders = paymentDetailsFilter.htlcStatus.map(() => "?");
            if (htlcAlias === "l") {
              paymentDetailsClauses.push(
                `l.htlc_status IN (${placeholders.join(", ")})`
              );
            } else {
              paymentDetailsClauses.push(
                `JSON_UNQUOTE(JSON_EXTRACT(s.htlc_details, '$.status')) IN (${placeholders.join(", ")})`
              );
            }
            params.push(...paymentDetailsFilter.htlcStatus);
          }

          // Conversion filter — same enum shape as the Rust storage backend:
          //   "ammRefundNeeded"   → AMM conversion that needs a clawback
          //   "orchestraPending"  → Orchestra order not yet terminal
          //   "boltzPending"      → Boltz reverse swap not yet terminal
          //                         (lives on the Lightning hold-invoice leg)
          if (
            (paymentDetailsFilter.type === "spark" ||
              paymentDetailsFilter.type === "token" ||
              paymentDetailsFilter.type === "lightning") &&
            paymentDetailsFilter.conversionFilter !== undefined
          ) {
            let statusClause;
            if (paymentDetailsFilter.conversionFilter === "ammRefundNeeded") {
              statusClause =
                "JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.type')) = 'amm' AND \
                 JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.status')) = 'refundNeeded'";
            } else if (
              paymentDetailsFilter.conversionFilter === "orchestraPending"
            ) {
              statusClause =
                "JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.type')) = 'orchestra' AND \
                 JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.status')) NOT IN ('completed', 'failed', 'refunded')";
            } else if (
              paymentDetailsFilter.conversionFilter === "boltzPending"
            ) {
              statusClause =
                "JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.type')) = 'boltz' AND \
                 JSON_UNQUOTE(JSON_EXTRACT(pm.conversion_info, '$.status')) NOT IN ('completed', 'failed', 'refunded')";
            }
            if (statusClause) {
              paymentDetailsClauses.push(
                `pm.conversion_info IS NOT NULL AND ${statusClause}`
              );
            }
          }

          if (
            paymentDetailsFilter.type === "token" &&
            paymentDetailsFilter.txHash !== undefined
          ) {
            paymentDetailsClauses.push("t.tx_hash = ?");
            params.push(paymentDetailsFilter.txHash);
          }

          if (
            paymentDetailsFilter.type === "token" &&
            paymentDetailsFilter.txType !== undefined
          ) {
            paymentDetailsClauses.push("t.tx_type = ?");
            params.push(paymentDetailsFilter.txType);
          }

          if (paymentDetailsClauses.length > 0) {
            allPaymentDetailsClauses.push(
              `(${paymentDetailsClauses.join(" AND ")})`
            );
          }
        }

        if (allPaymentDetailsClauses.length > 0) {
          whereClauses.push(`(${allPaymentDetailsClauses.join(" OR ")})`);
        }
      }

      if (request.assetFilter) {
        const assetFilter = request.assetFilter;
        if (assetFilter.type === "bitcoin") {
          whereClauses.push("t.metadata IS NULL");
        } else if (assetFilter.type === "token") {
          whereClauses.push("t.metadata IS NOT NULL");
          if (assetFilter.tokenIdentifier) {
            whereClauses.push(
              "JSON_UNQUOTE(JSON_EXTRACT(t.metadata, '$.identifier')) = ?"
            );
            params.push(assetFilter.tokenIdentifier);
          }
        }
      }

      whereClauses.push("pm.parent_payment_id IS NULL");

      const whereSql =
        whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

      const orderDirection = request.sortAscending ? "ASC" : "DESC";
      const query = `${SELECT_PAYMENT_SQL} ${whereSql} ORDER BY p.timestamp ${orderDirection} LIMIT ? OFFSET ?`;

      params.push(actualLimit, actualOffset);
      const [rows] = await this.pool.query(query, params);
      return rows.map(this._rowToPayment.bind(this));
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to list payments (request: ${toJson(request)}): ${error.message}`,
        error
      );
    }
  }

  async applyPaymentUpdate(payment) {
    if (!payment) {
      throw new StorageError("Payment cannot be null or undefined");
    }

    let conn = null;
    const lockName = this._paymentUpdateLockName(payment.id);
    let acquired = false;
    let shouldEmit = false;
    let operationError = null;
    let releaseError = null;

    try {
      conn = await this.pool.getConnection();
      const [lockRows] = await conn.query("SELECT GET_LOCK(?, ?) AS acquired", [
        lockName,
        PAYMENT_UPDATE_LOCK_TIMEOUT_SECS,
      ]);
      acquired = Number(lockRows?.[0]?.acquired) === 1;
      if (!acquired) {
        throw new StorageError(`Timed out acquiring payment update lock '${lockName}'`);
      }

      await conn.query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
      await conn.beginTransaction();
      try {
        const [rows] = await conn.query(
          "SELECT status FROM brz_payments WHERE user_id = ? AND id = ? FOR UPDATE",
          [this.identity, payment.id]
        );
        const stored = rows.length > 0
          ? this._normalizePaymentStatus(rows[0].status)
          : null;
        const next = this._normalizePaymentStatus(payment.status);

        if (stored == null) {
          await this._runPaymentUpsert(conn, payment);
          shouldEmit = true;
        } else if (stored === next) {
          console.debug(
            `Skipping redundant payment event: id=${payment.id} status=${next}`
          );
          await this._runPaymentUpsert(conn, payment);
          shouldEmit = false;
        } else if (this._isFinalPaymentStatus(stored)) {
          console.warn(
            `Skipping payment update (would replace terminal status): id=${payment.id} stored=${stored} new=${next}`
          );
          shouldEmit = false;
        } else {
          await this._runPaymentUpsert(conn, payment);
          shouldEmit = true;
        }

        await conn.commit();
      } catch (error) {
        await conn.rollback().catch(() => {});
        throw error;
      }
    } catch (error) {
      operationError = error;
    } finally {
      if (conn && acquired) {
        try {
          await conn.query("SELECT RELEASE_LOCK(?)", [lockName]);
        } catch (error) {
          releaseError = error;
        }
      }
      if (conn) {
        conn.release();
      }
    }

    if (operationError) {
      if (operationError instanceof StorageError) {
        throw operationError;
      }
      throw new StorageError(
        `Failed to apply payment update '${payment.id}': ${operationError.message}`,
        operationError
      );
    }

    if (releaseError) {
      throw new StorageError(
        `Failed to release payment update lock '${lockName}': ${releaseError.message}`,
        releaseError
      );
    }

    return shouldEmit;
  }

  async _runPaymentUpsert(conn, payment) {
    const withdrawTxId =
      payment.details?.type === "withdraw" ? payment.details.txId : null;
    const spark = payment.details?.type === "spark" ? 1 : null;

    await conn.query(
      `INSERT INTO brz_payments (user_id, id, payment_type, status, amount, fees, timestamp, method, withdraw_tx_id, spark)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         payment_type=VALUES(payment_type),
         status=VALUES(status),
         amount=VALUES(amount),
         fees=VALUES(fees),
         timestamp=VALUES(timestamp),
         method=VALUES(method),
         withdraw_tx_id=VALUES(withdraw_tx_id),
         spark=VALUES(spark)`,
      [
        this.identity,
        payment.id,
        payment.paymentType,
        payment.status,
        payment.amount.toString(),
        payment.fees.toString(),
        payment.timestamp,
        payment.method ? toJson(payment.method) : null,
        withdrawTxId,
        spark,
      ]
    );

    if (payment.details?.type === "deposit") {
      await conn.query(
        `INSERT INTO brz_payment_details_deposit (user_id, payment_id, tx_id, vout)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           tx_id=VALUES(tx_id),
           vout=VALUES(vout)`,
        [this.identity, payment.id, payment.details.txId, payment.details.vout]
      );
    }

    if (
      payment.details?.type === "spark" &&
      (payment.details.invoiceDetails != null ||
        payment.details.htlcDetails != null)
    ) {
      await conn.query(
        `INSERT INTO brz_payment_details_spark (user_id, payment_id, invoice_details, htlc_details)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           invoice_details=COALESCE(VALUES(invoice_details), invoice_details),
           htlc_details=COALESCE(VALUES(htlc_details), htlc_details)`,
        [
          this.identity,
          payment.id,
          payment.details.invoiceDetails
            ? toJson(payment.details.invoiceDetails)
            : null,
          payment.details.htlcDetails
            ? toJson(payment.details.htlcDetails)
            : null,
        ]
      );
    }

    if (payment.details?.type === "lightning") {
      await conn.query(
        `INSERT INTO brz_payment_details_lightning
          (user_id, payment_id, invoice, payment_hash, destination_pubkey, description, preimage, htlc_status, htlc_expiry_time)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            invoice=VALUES(invoice),
            payment_hash=VALUES(payment_hash),
            destination_pubkey=VALUES(destination_pubkey),
            description=VALUES(description),
            preimage=COALESCE(VALUES(preimage), preimage),
            htlc_status=COALESCE(VALUES(htlc_status), htlc_status),
            htlc_expiry_time=COALESCE(VALUES(htlc_expiry_time), htlc_expiry_time)`,
        [
          this.identity,
          payment.id,
          payment.details.invoice,
          payment.details.htlcDetails.paymentHash,
          payment.details.destinationPubkey,
          payment.details.description,
          payment.details.htlcDetails?.preimage,
          payment.details.htlcDetails?.status ?? null,
          payment.details.htlcDetails?.expiryTime ?? 0,
        ]
      );
    }

    if (payment.details?.type === "token") {
      await conn.query(
        `INSERT INTO brz_payment_details_token
          (user_id, payment_id, metadata, tx_hash, tx_type, invoice_details)
          VALUES (?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            metadata=VALUES(metadata),
            tx_hash=VALUES(tx_hash),
            tx_type=VALUES(tx_type),
            invoice_details=COALESCE(VALUES(invoice_details), invoice_details)`,
        [
          this.identity,
          payment.id,
          toJson(payment.details.metadata),
          payment.details.txHash,
          payment.details.txType,
          payment.details.invoiceDetails
            ? toJson(payment.details.invoiceDetails)
            : null,
        ]
      );
    }
  }

  _paymentUpdateLockName(paymentId) {
    return crypto
      .createHash("sha256")
      .update("brz_payment_update")
      .update(this.identity)
      .update(Buffer.from(paymentId))
      .digest("hex")
      .slice(0, 32);
  }

  _normalizePaymentStatus(status) {
    return typeof status === "string" ? status.toLowerCase() : status;
  }

  _isFinalPaymentStatus(status) {
    const normalized = this._normalizePaymentStatus(status);
    return normalized === "completed" || normalized === "failed";
  }


  async getPaymentById(id) {
    try {
      if (!id) {
        throw new StorageError("Payment ID cannot be null or undefined");
      }

      const [rows] = await this.pool.query(
        `${SELECT_PAYMENT_SQL} WHERE p.user_id = ? AND p.id = ?`,
        [this.identity, id]
      );

      if (rows.length === 0) {
        throw new StorageError(`Payment with id '${id}' not found`);
      }

      return this._rowToPayment(rows[0]);
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payment by id '${id || "unknown"}': ${error.message}`,
        error
      );
    }
  }

  async getPaymentByInvoice(invoice) {
    try {
      if (!invoice) {
        throw new StorageError("Invoice cannot be null or undefined");
      }

      const [rows] = await this.pool.query(
        `${SELECT_PAYMENT_SQL} WHERE p.user_id = ? AND l.invoice = ?`,
        [this.identity, invoice]
      );

      if (rows.length === 0) {
        return null;
      }

      return this._rowToPayment(rows[0]);
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payment by invoice '${invoice}': ${error.message}`,
        error
      );
    }
  }

  async getPaymentsByParentIds(parentPaymentIds) {
    try {
      if (!parentPaymentIds || parentPaymentIds.length === 0) {
        return {};
      }

      // Early exit if no related payments exist for this tenant. mysql2 returns EXISTS as 0/1.
      const [hasRelatedRows] = await this.pool.query(
        "SELECT EXISTS(SELECT 1 FROM brz_payment_metadata WHERE user_id = ? AND parent_payment_id IS NOT NULL LIMIT 1) AS has_related",
        [this.identity]
      );
      if (!hasRelatedRows[0].has_related) {
        return {};
      }

      const placeholders = parentPaymentIds.map(() => "?");
      const query = `${SELECT_PAYMENT_SQL} WHERE p.user_id = ? AND pm.parent_payment_id IN (${placeholders.join(", ")}) ORDER BY p.timestamp ASC`;

      const [rows] = await this.pool.query(query, [this.identity, ...parentPaymentIds]);

      const result = {};
      for (const row of rows) {
        const parentId = row.parent_payment_id;
        if (!result[parentId]) {
          result[parentId] = [];
        }
        result[parentId].push(this._rowToPayment(row));
      }

      return result;
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to get payments by parent ids: ${error.message}`,
        error
      );
    }
  }

  async insertPaymentMetadata(paymentId, metadata) {
    try {
      await this.pool.query(
        `INSERT INTO brz_payment_metadata (user_id, payment_id, parent_payment_id, lnurl_pay_info, lnurl_withdraw_info, lnurl_description, conversion_info, conversion_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           parent_payment_id = COALESCE(VALUES(parent_payment_id), parent_payment_id),
           lnurl_pay_info = COALESCE(VALUES(lnurl_pay_info), lnurl_pay_info),
           lnurl_withdraw_info = COALESCE(VALUES(lnurl_withdraw_info), lnurl_withdraw_info),
           lnurl_description = COALESCE(VALUES(lnurl_description), lnurl_description),
           conversion_info = COALESCE(VALUES(conversion_info), conversion_info),
           conversion_status = COALESCE(VALUES(conversion_status), conversion_status)`,
        [
          this.identity,
          paymentId,
          metadata.parentPaymentId,
          metadata.lnurlPayInfo
            ? toJson(metadata.lnurlPayInfo)
            : null,
          metadata.lnurlWithdrawInfo
            ? toJson(metadata.lnurlWithdrawInfo)
            : null,
          metadata.lnurlDescription,
          metadata.conversionInfo
            ? toJson(metadata.conversionInfo)
            : null,
          metadata.conversionStatus ?? null,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set payment metadata for '${paymentId}': ${error.message}`,
        error
      );
    }
  }

  // ===== Deposit Operations =====

  async addDeposit(txid, vout, amountSats, isMature) {
    try {
      await this.pool.query(
        `INSERT INTO brz_unclaimed_deposits (user_id, txid, vout, amount_sats, is_mature)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE is_mature = VALUES(is_mature), amount_sats = VALUES(amount_sats)`,
        [this.identity, txid, vout, amountSats, isMature ? 1 : 0]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to add deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async deleteDeposit(txid, vout) {
    try {
      await this.pool.query(
        "DELETE FROM brz_unclaimed_deposits WHERE user_id = ? AND txid = ? AND vout = ?",
        [this.identity, txid, vout]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async listDeposits() {
    try {
      const [rows] = await this.pool.query(
        "SELECT txid, vout, amount_sats, is_mature, claim_error, refund_tx, refund_tx_id, instant_claim_status, refund_state, max_claim_fee FROM brz_unclaimed_deposits WHERE user_id = ?",
        [this.identity]
      );

      return rows.map((row) => ({
        txid: row.txid,
        vout: row.vout,
        amountSats:
          row.amount_sats != null ? BigInt(row.amount_sats) : BigInt(0),
        isMature: toBool(row.is_mature) ?? true,
        claimError: parseJson(row.claim_error),
        refundTx: row.refund_tx,
        refundTxId: row.refund_tx_id,
        instantClaimStatus: parseJson(row.instant_claim_status),
        refundState: parseJson(row.refund_state),
        maxClaimFee: parseJson(row.max_claim_fee),
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list deposits: ${error.message}`,
        error
      );
    }
  }

  async updateDeposit(txid, vout, payload) {
    try {
      if (payload.type === "claimError") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET claim_error = ?
           WHERE user_id = ? AND txid = ? AND vout = ?`,
          [toJson(payload.error), this.identity, txid, vout]
        );
      } else if (payload.type === "refund") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET refund_tx = ?, refund_tx_id = ?, refund_state = ?, claim_error = NULL
           WHERE user_id = ? AND txid = ? AND vout = ?`,
          [
            payload.refundTx,
            payload.refundTxid,
            toJson(payload.state),
            this.identity,
            txid,
            vout,
          ]
        );
      } else if (payload.type === "instantClaim") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET instant_claim_status = ?
           WHERE user_id = ? AND txid = ? AND vout = ?`,
          [toJson(payload.status), this.identity, txid, vout]
        );
      } else if (payload.type === "refundBroadcastState") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET refund_state = ?
           WHERE user_id = ? AND txid = ? AND vout = ? AND refund_tx_id = ?`,
          [
            toJson(payload.state),
            this.identity,
            txid,
            vout,
            payload.refundTxid,
          ]
        );
      } else if (payload.type === "maxClaimFee") {
        await this.pool.query(
          `UPDATE brz_unclaimed_deposits
           SET max_claim_fee = ?
           WHERE user_id = ? AND txid = ? AND vout = ?`,
          [
            payload.maxFee ? toJson(payload.maxFee) : null,
            this.identity,
            txid,
            vout,
          ]
        );
      } else {
        throw new StorageError(`Unknown payload type: ${payload.type}`);
      }
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update deposit '${txid}:${vout}': ${error.message}`,
        error
      );
    }
  }

  async listWatchedDepositAddresses() {
    try {
      const [rows] = await this.pool.query(
        `SELECT address, issued_at, seen FROM brz_watched_deposit_addresses
           WHERE user_id = ? ORDER BY issued_at DESC`,
        [this.identity]
      );
      return rows.map((row) => ({
        address: row.address,
        issuedAt: BigInt(row.issued_at),
        seen: toBool(row.seen) ?? false,
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list watched deposit addresses: ${error.message}`,
        error
      );
    }
  }

  async updateWatchedDepositAddress(address, payload) {
    try {
      if (payload.type === "watch") {
        await this.pool.query(
          `INSERT INTO brz_watched_deposit_addresses (user_id, address, issued_at, seen)
             VALUES (?, ?, ?, FALSE)
             ON DUPLICATE KEY UPDATE issued_at = VALUES(issued_at), seen = FALSE`,
          [this.identity, address, String(payload.issuedAt)]
        );
      } else if (payload.type === "seen") {
        await this.pool.query(
          `UPDATE brz_watched_deposit_addresses SET seen = TRUE
             WHERE user_id = ? AND address = ?`,
          [this.identity, address]
        );
      } else if (payload.type === "unwatch") {
        await this.pool.query(
          `DELETE FROM brz_watched_deposit_addresses
             WHERE user_id = ? AND address = ? AND issued_at = ?`,
          [this.identity, address, String(payload.issuedAt)]
        );
      } else {
        throw new StorageError(`Unknown payload type: ${payload.type}`);
      }
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update watched deposit address '${address}': ${error.message}`,
        error
      );
    }
  }

  async listLeafRecoveries() {
    try {
      const [rows] = await this.pool.query(
        `SELECT l.leaf_id,
                l.chain_checked_at,
                o.txid AS output_txid,
                o.vout AS output_vout,
                o.amount_sats AS output_amount_sats,
                o.script_pubkey AS output_script_pubkey,
                ot.block_height AS output_block_height,
                s.txid AS spend_txid,
                st.block_height AS spend_block_height,
                w.txid AS sweep_txid,
                wt.block_height AS sweep_block_height,
                r.txid AS recovery_txid,
                r.transaction_hex AS recovery_transaction_hex,
                r.output_amount_sats AS recovery_output_amount_sats
           FROM brz_leaf_recoveries l
           LEFT JOIN brz_watchtower_exit_outputs o
             ON o.user_id = l.user_id AND o.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions ot
             ON ot.user_id = o.user_id AND ot.txid = o.txid
           LEFT JOIN brz_watchtower_exit_spends s
             ON s.user_id = l.user_id AND s.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions st
             ON st.user_id = s.user_id AND st.txid = s.txid
           LEFT JOIN brz_unilateral_exit_sweeps w
             ON w.user_id = l.user_id AND w.leaf_id = l.leaf_id
           LEFT JOIN brz_chain_transactions wt
             ON wt.user_id = w.user_id AND wt.txid = w.txid
           LEFT JOIN brz_watchtower_exit_recoveries r
             ON r.user_id = l.user_id AND r.leaf_id = l.leaf_id
           WHERE l.user_id = ?
           ORDER BY l.leaf_id, r.txid`,
        [this.identity]
      );
      return leafRecoveriesFromRows(rows);
    } catch (error) {
      throw new StorageError(
        `Failed to list leaf recoveries: ${error.message}`,
        error
      );
    }
  }

  async updateLeafRecovery(update) {
    try {
      const leafId = update.leafId;
      await this._withTransaction(async (conn) => {
        const setChainTransaction = (txid, blockHeight) =>
          conn.query(
            `INSERT INTO brz_chain_transactions (user_id, txid, block_height)
               VALUES (?, ?, ?)
               ON DUPLICATE KEY UPDATE block_height = VALUES(block_height)`,
            [this.identity, txid, blockHeight]
          );

        // MySQL locks the leaf's row, so writers of one leaf do not interleave.
        await conn.query(
          `INSERT INTO brz_leaf_recoveries (user_id, leaf_id) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE leaf_id = leaf_id`,
          [this.identity, leafId]
        );
        if (update.chainCheckedAt != null) {
          // The parameter is a string, and MySQL would compare it with the
          // stored time as strings. CAST makes MySQL compare them as numbers.
          await conn.query(
            `UPDATE brz_leaf_recoveries
               SET chain_checked_at =
                 GREATEST(COALESCE(chain_checked_at, 0), CAST(? AS SIGNED))
               WHERE user_id = ? AND leaf_id = ?`,
            [String(update.chainCheckedAt), this.identity, leafId]
          );
        }
        if (update.watchtowerExitOutput != null) {
          const output = update.watchtowerExitOutput;
          for (const table of [
            "brz_watchtower_exit_recoveries",
            "brz_watchtower_exit_spends",
          ]) {
            await conn.query(
              `DELETE FROM ${table}
                 WHERE user_id = ? AND leaf_id = ? AND EXISTS (
                   SELECT 1 FROM brz_watchtower_exit_outputs
                   WHERE user_id = ? AND leaf_id = ? AND (txid <> ? OR vout <> ?))`,
              [
                this.identity,
                leafId,
                this.identity,
                leafId,
                output.txid,
                output.vout,
              ]
            );
          }
          await setChainTransaction(output.txid, output.blockHeight);
          await conn.query(
            `INSERT INTO brz_watchtower_exit_outputs
                 (user_id, leaf_id, txid, vout, amount_sats, script_pubkey)
               VALUES (?, ?, ?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE
                 txid = VALUES(txid),
                 vout = VALUES(vout),
                 amount_sats = VALUES(amount_sats),
                 script_pubkey = VALUES(script_pubkey)`,
            [
              this.identity,
              leafId,
              output.txid,
              output.vout,
              String(output.amountSats),
              output.scriptPubkey,
            ]
          );
        }
        if (update.watchtowerExitRecovery != null) {
          const recovery = update.watchtowerExitRecovery;
          await conn.query(
            `INSERT INTO brz_watchtower_exit_recoveries
                 (user_id, leaf_id, txid, transaction_hex, output_amount_sats)
               VALUES (?, ?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE txid = txid`,
            [
              this.identity,
              leafId,
              recovery.txid,
              recovery.transactionHex,
              String(recovery.outputAmountSats),
            ]
          );
        }
        for (const [table, chainTransaction] of [
          ["brz_watchtower_exit_spends", update.watchtowerExitSpend],
          ["brz_unilateral_exit_sweeps", update.unilateralExitSweep],
        ]) {
          if (chainTransaction == null) {
            continue;
          }
          await setChainTransaction(
            chainTransaction.txid,
            chainTransaction.blockHeight
          );
          await conn.query(
            `INSERT INTO ${table} (user_id, leaf_id, txid) VALUES (?, ?, ?)
               ON DUPLICATE KEY UPDATE txid = VALUES(txid)`,
            [this.identity, leafId, chainTransaction.txid]
          );
        }
      });
    } catch (error) {
      throw new StorageError(
        `Failed to update leaf recovery '${update.leafId}': ${error.message}`,
        error
      );
    }
  }

  async setLnurlMetadata(metadata) {
    try {
      await this._withTransaction(async (conn) => {
        for (const item of metadata) {
          await conn.query(
            `INSERT INTO brz_lnurl_receive_metadata (user_id, payment_hash, nostr_zap_request, nostr_zap_receipt, sender_comment)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               nostr_zap_request = VALUES(nostr_zap_request),
               nostr_zap_receipt = VALUES(nostr_zap_receipt),
               sender_comment = VALUES(sender_comment)`,
            [
              this.identity,
              item.paymentHash,
              item.nostrZapRequest || null,
              item.nostrZapReceipt || null,
              item.senderComment || null,
            ]
          );
        }
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to add lnurl metadata: ${error.message}`,
        error
      );
    }
  }

  // ===== Private Helper Methods =====

  _rowToPayment(row) {
    let details = null;
    if (row.lightning_invoice) {
      details = {
        type: "lightning",
        invoice: row.lightning_invoice,
        destinationPubkey: row.lightning_destination_pubkey,
        description: row.lightning_description,
        htlcDetails: row.lightning_htlc_status
          ? {
              paymentHash: row.lightning_payment_hash,
              preimage: row.lightning_preimage || null,
              expiryTime: Number(row.lightning_htlc_expiry_time) ?? 0,
              status: row.lightning_htlc_status,
            }
          : (() => {
              throw new StorageError(
                `htlc_status is required for Lightning payment ${row.id}`
              );
            })(),
      };

      if (row.lnurl_pay_info) {
        details.lnurlPayInfo = parseJson(row.lnurl_pay_info);
      }

      if (row.lnurl_withdraw_info) {
        details.lnurlWithdrawInfo = parseJson(row.lnurl_withdraw_info);
      }

      if (row.lnurl_payment_hash) {
        details.lnurlReceiveMetadata = {
          nostrZapRequest: row.lnurl_nostr_zap_request || null,
          nostrZapReceipt: row.lnurl_nostr_zap_receipt || null,
          senderComment: row.lnurl_sender_comment || null,
        };
      }

      if (row.conversion_info) {
        details.conversionInfo = parseJson(row.conversion_info);
      }
    } else if (row.withdraw_tx_id) {
      details = {
        type: "withdraw",
        txId: row.withdraw_tx_id,
      };
    } else if (row.deposit_tx_id) {
      details = {
        type: "deposit",
        txId: row.deposit_tx_id,
        vout: Number(row.deposit_vout),
      };
    } else if (toBool(row.spark)) {
      details = {
        type: "spark",
        invoiceDetails: parseJson(row.spark_invoice_details),
        htlcDetails: parseJson(row.spark_htlc_details),
        conversionInfo: parseJson(row.conversion_info),
      };
    } else if (row.token_metadata) {
      details = {
        type: "token",
        metadata: parseJson(row.token_metadata),
        txHash: row.token_tx_hash,
        txType: row.token_tx_type,
        invoiceDetails: parseJson(row.token_invoice_details),
        conversionInfo: parseJson(row.conversion_info),
      };
    }

    let method = null;
    if (row.method) {
      try {
        method = parseJson(row.method);
      } catch (e) {
        throw new StorageError(
          `Failed to parse payment method JSON for payment ${row.id}: ${e.message}`,
          e
        );
      }
    }

    return {
      id: row.id,
      paymentType: row.payment_type,
      status: row.status,
      amount: BigInt(row.amount),
      fees: BigInt(row.fees),
      timestamp: Number(row.timestamp),
      method,
      details,
      conversionDetails: row.conversion_status
        ? { status: row.conversion_status, from: null, to: null }
        : null,
    };
  }

  // ===== Contact Operations =====

  async listContacts(request) {
    try {
      const offset = request.offset != null ? request.offset : 0;
      const limit = request.limit != null ? request.limit : 4294967295;

      const [rows] = await this.pool.query(
        `SELECT id, name, payment_identifier, created_at, updated_at
         FROM brz_contacts
         WHERE user_id = ?
         ORDER BY name ASC
         LIMIT ? OFFSET ?`,
        [this.identity, limit, offset]
      );

      return rows.map((row) => ({
        id: row.id,
        name: row.name,
        paymentIdentifier: row.payment_identifier,
        createdAt: Number(row.created_at),
        updatedAt: Number(row.updated_at),
      }));
    } catch (error) {
      throw new StorageError(
        `Failed to list contacts: ${error.message}`,
        error
      );
    }
  }

  async getContact(id) {
    try {
      const [rows] = await this.pool.query(
        `SELECT id, name, payment_identifier, created_at, updated_at
         FROM brz_contacts
         WHERE user_id = ? AND id = ?`,
        [this.identity, id]
      );

      if (rows.length === 0) {
        return null;
      }

      const row = rows[0];
      return {
        id: row.id,
        name: row.name,
        paymentIdentifier: row.payment_identifier,
        createdAt: Number(row.created_at),
        updatedAt: Number(row.updated_at),
      };
    } catch (error) {
      throw new StorageError(`Failed to get contact: ${error.message}`, error);
    }
  }

  async insertContact(contact) {
    try {
      await this.pool.query(
        `INSERT INTO brz_contacts (user_id, id, name, payment_identifier, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           payment_identifier = VALUES(payment_identifier),
           updated_at = VALUES(updated_at)`,
        [
          this.identity,
          contact.id,
          contact.name,
          contact.paymentIdentifier,
          contact.createdAt,
          contact.updatedAt,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to insert contact: ${error.message}`,
        error
      );
    }
  }

  async deleteContact(id) {
    try {
      await this.pool.query(
        "DELETE FROM brz_contacts WHERE user_id = ? AND id = ?",
        [this.identity, id]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete contact: ${error.message}`,
        error
      );
    }
  }

  // ===== Cross-Chain Swap Operations =====

  async setCrossChainSwap(swap) {
    try {
      await this.pool.query(
        `INSERT INTO brz_cross_chain_swaps
           (user_id, provider, id, is_terminal, updated_at, data, secrets)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           is_terminal = VALUES(is_terminal),
           updated_at = VALUES(updated_at),
           data = VALUES(data),
           secrets = VALUES(secrets)`,
        [
          this.identity,
          swap.provider,
          swap.id,
          swap.isTerminal ? 1 : 0,
          swap.updatedAt,
          swap.data,
          swap.secrets,
        ]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to set cross-chain swap: ${error.message}`,
        error
      );
    }
  }

  async getCrossChainSwap(provider, id) {
    try {
      const [rows] = await this.pool.query(
        `SELECT provider, id, is_terminal, updated_at, data, secrets
         FROM brz_cross_chain_swaps
         WHERE user_id = ? AND provider = ? AND id = ?`,
        [this.identity, provider, id]
      );
      if (rows.length === 0) {
        return null;
      }
      return crossChainSwapFromRow(rows[0]);
    } catch (error) {
      throw new StorageError(
        `Failed to get cross-chain swap: ${error.message}`,
        error
      );
    }
  }

  async listActiveCrossChainSwaps(provider) {
    try {
      const [rows] = await this.pool.query(
        `SELECT provider, id, is_terminal, updated_at, data, secrets
         FROM brz_cross_chain_swaps
         WHERE user_id = ? AND provider = ? AND is_terminal = FALSE`,
        [this.identity, provider]
      );
      return rows.map(crossChainSwapFromRow);
    } catch (error) {
      throw new StorageError(
        `Failed to list active cross-chain swaps: ${error.message}`,
        error
      );
    }
  }

  // ===== Sync Operations =====

  async syncAddOutgoingChange(record) {
    try {
      return await this._withTransaction(async (conn) => {
        // The local queue revision is per-tenant — two tenants don't share a queue.
        const [revisionRows] = await conn.query(
          "SELECT COALESCE(MAX(revision), 0) + 1 AS revision FROM brz_sync_outgoing WHERE user_id = ?",
          [this.identity]
        );
        const revision = BigInt(revisionRows[0].revision);

        await conn.query(
          `INSERT INTO brz_sync_outgoing (
            user_id,
            record_type,
            data_id,
            schema_version,
            commit_time,
            updated_fields_json,
            revision
          ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.updatedFields),
            revision.toString(),
          ]
        );

        return revision;
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to add outgoing change: ${error.message}`,
        error
      );
    }
  }

  async syncCompleteOutgoingSync(record, localRevision) {
    try {
      await this._withTransaction(async (conn) => {
        const [deleteResult] = await conn.query(
          "DELETE FROM brz_sync_outgoing WHERE user_id = ? AND record_type = ? AND data_id = ? AND revision = ?",
          [this.identity, record.id.type, record.id.dataId, localRevision.toString()]
        );

        if (deleteResult.affectedRows === 0) {
          const msg = `complete_outgoing_sync: DELETE from brz_sync_outgoing matched 0 rows (type=${record.id.type}, data_id=${record.id.dataId}, revision=${localRevision})`;
          if (this.logger && typeof this.logger.log === "function") {
            this.logger.log({ line: msg, level: "warn" });
          } else {
            console.warn(`[MysqlStorage] ${msg}`);
          }
        }

        await conn.query(
          `INSERT INTO brz_sync_state (
            user_id,
            record_type,
            data_id,
            revision,
            schema_version,
            commit_time,
            data
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            schema_version = VALUES(schema_version),
            commit_time = VALUES(commit_time),
            data = VALUES(data),
            revision = VALUES(revision)`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.revision.toString(),
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.data),
          ]
        );

        // Upsert this tenant's revision row; fresh tenants without a row get one.
        await conn.query(
          `INSERT INTO brz_sync_revision (user_id, revision) VALUES (?, ?)
           ON DUPLICATE KEY UPDATE revision = GREATEST(revision, VALUES(revision))`,
          [this.identity, record.revision.toString()]
        );
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to complete outgoing sync: ${error.message}`,
        error
      );
    }
  }

  async syncGetPendingOutgoingChanges(limit) {
    try {
      const [rows] = await this.pool.query(
        `SELECT
          o.record_type,
          o.data_id,
          o.schema_version,
          o.commit_time,
          o.updated_fields_json,
          o.revision,
          e.schema_version AS existing_schema_version,
          e.commit_time AS existing_commit_time,
          e.data AS existing_data,
          e.revision AS existing_revision
        FROM brz_sync_outgoing o
        LEFT JOIN brz_sync_state e ON
          o.record_type = e.record_type AND
          o.data_id = e.data_id AND
          o.user_id = e.user_id
        WHERE o.user_id = ?
        ORDER BY o.revision ASC
        LIMIT ?`,
        [this.identity, limit]
      );

      return rows.map((row) => {
        const change = {
          id: { type: row.record_type, dataId: row.data_id },
          schemaVersion: row.schema_version,
          updatedFields: parseJson(row.updated_fields_json),
          localRevision: BigInt(row.revision),
        };

        let parent = null;
        if (row.existing_data) {
          parent = {
            id: { type: row.record_type, dataId: row.data_id },
            revision: BigInt(row.existing_revision),
            schemaVersion: row.existing_schema_version,
            data: parseJson(row.existing_data),
          };
        }

        return { change, parent };
      });
    } catch (error) {
      throw new StorageError(
        `Failed to get pending outgoing changes: ${error.message}`,
        error
      );
    }
  }

  async syncGetLastRevision() {
    try {
      // A tenant that hasn't synced anything yet may have no row; treat as 0.
      const [rows] = await this.pool.query(
        "SELECT revision FROM brz_sync_revision WHERE user_id = ?",
        [this.identity]
      );
      return rows.length > 0 ? BigInt(rows[0].revision) : BigInt(0);
    } catch (error) {
      throw new StorageError(
        `Failed to get last revision: ${error.message}`,
        error
      );
    }
  }

  async syncInsertIncomingRecords(records) {
    try {
      if (!records || records.length === 0) {
        return;
      }

      await this._withTransaction(async (conn) => {
        for (const record of records) {
          await conn.query(
            `INSERT INTO brz_sync_incoming (
              user_id,
              record_type,
              data_id,
              schema_version,
              commit_time,
              data,
              revision
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
              schema_version = VALUES(schema_version),
              commit_time = VALUES(commit_time),
              data = VALUES(data)`,
            [
              this.identity,
              record.id.type,
              record.id.dataId,
              record.schemaVersion,
              Math.floor(Date.now() / 1000),
              toJson(record.data),
              record.revision.toString(),
            ]
          );
        }
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to insert incoming records: ${error.message}`,
        error
      );
    }
  }

  async syncDeleteIncomingRecord(record) {
    try {
      await this.pool.query(
        `DELETE FROM brz_sync_incoming
         WHERE user_id = ?
         AND record_type = ?
         AND data_id = ?
         AND revision = ?`,
        [this.identity, record.id.type, record.id.dataId, record.revision.toString()]
      );
    } catch (error) {
      throw new StorageError(
        `Failed to delete incoming record: ${error.message}`,
        error
      );
    }
  }

  async syncGetIncomingRecords(limit) {
    try {
      const [rows] = await this.pool.query(
        `SELECT i.record_type,
                i.data_id,
                i.schema_version,
                i.data,
                i.revision,
                e.schema_version AS existing_schema_version,
                e.commit_time AS existing_commit_time,
                e.data AS existing_data,
                e.revision AS existing_revision
         FROM brz_sync_incoming i
         LEFT JOIN brz_sync_state e ON i.record_type = e.record_type AND i.data_id = e.data_id AND i.user_id = e.user_id
         WHERE i.user_id = ?
         ORDER BY i.revision ASC
         LIMIT ?`,
        [this.identity, limit]
      );

      return rows.map((row) => {
        const newState = {
          id: { type: row.record_type, dataId: row.data_id },
          revision: BigInt(row.revision),
          schemaVersion: row.schema_version,
          data: parseJson(row.data),
        };

        let oldState = null;
        if (row.existing_data) {
          oldState = {
            id: { type: row.record_type, dataId: row.data_id },
            revision: BigInt(row.existing_revision),
            schemaVersion: row.existing_schema_version,
            data: parseJson(row.existing_data),
          };
        }

        return { newState, oldState };
      });
    } catch (error) {
      throw new StorageError(
        `Failed to get incoming records: ${error.message}`,
        error
      );
    }
  }

  async syncGetLatestOutgoingChange() {
    try {
      const [rows] = await this.pool.query(
        `SELECT
          o.record_type,
          o.data_id,
          o.schema_version,
          o.commit_time,
          o.updated_fields_json,
          o.revision,
          e.schema_version AS existing_schema_version,
          e.commit_time AS existing_commit_time,
          e.data AS existing_data,
          e.revision AS existing_revision
        FROM brz_sync_outgoing o
        LEFT JOIN brz_sync_state e ON
          o.record_type = e.record_type AND
          o.data_id = e.data_id AND
          o.user_id = e.user_id
        WHERE o.user_id = ?
        ORDER BY o.revision DESC
        LIMIT 1`,
        [this.identity]
      );

      if (rows.length === 0) {
        return null;
      }

      const row = rows[0];

      const change = {
        id: { type: row.record_type, dataId: row.data_id },
        schemaVersion: row.schema_version,
        updatedFields: parseJson(row.updated_fields_json),
        localRevision: BigInt(row.revision),
      };

      let parent = null;
      if (row.existing_data) {
        parent = {
          id: { type: row.record_type, dataId: row.data_id },
          revision: BigInt(row.existing_revision),
          schemaVersion: row.existing_schema_version,
          data: parseJson(row.existing_data),
        };
      }

      return { change, parent };
    } catch (error) {
      throw new StorageError(
        `Failed to get latest outgoing change: ${error.message}`,
        error
      );
    }
  }

  async syncUpdateRecordFromIncoming(record) {
    try {
      await this._withTransaction(async (conn) => {
        await conn.query(
          `INSERT INTO brz_sync_state (
            user_id,
            record_type,
            data_id,
            revision,
            schema_version,
            commit_time,
            data
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            schema_version = VALUES(schema_version),
            commit_time = VALUES(commit_time),
            data = VALUES(data),
            revision = VALUES(revision)`,
          [
            this.identity,
            record.id.type,
            record.id.dataId,
            record.revision.toString(),
            record.schemaVersion,
            Math.floor(Date.now() / 1000),
            toJson(record.data),
          ]
        );

        await conn.query(
          `INSERT INTO brz_sync_revision (user_id, revision) VALUES (?, ?)
           ON DUPLICATE KEY UPDATE revision = GREATEST(revision, VALUES(revision))`,
          [this.identity, record.revision.toString()]
        );
      });
    } catch (error) {
      if (error instanceof StorageError) throw error;
      throw new StorageError(
        `Failed to update record from incoming: ${error.message}`,
        error
      );
    }
  }
}

/**
 * Creates a MysqlStorageConfig with the given connection string and default pool settings.
 *
 * Default values:
 * - maxPoolSize: 10
 * - createTimeoutSecs: 0 (no timeout)
 * - recycleTimeoutSecs: 10 (10 seconds idle before disconnect)
 *
 * @param {string} connectionString - MySQL connection URL (mysql://user:pass@host:3306/db)
 * @returns {object} MySQL storage configuration
 */
function defaultMysqlStorageConfig(connectionString) {
  return {
    connectionString,
    maxPoolSize: 10,
    createTimeoutSecs: 0,
    recycleTimeoutSecs: 10,
    runMigration: true,
  };
}

/**
 * Translates the `ssl-mode` URL parameter into mysql2's `ssl` option.
 * mysql2 does not understand `ssl-mode`, so it is stripped from the URI here.
 *
 * Spellings mirror the Rust SDK:
 * - absent or `disabled`: no TLS
 * - `preferred` / `required` / `verify_identity`: TLS with certificate chain
 *   and hostname verification
 * - `verify_ca`: chain verification only
 * - `no-verify`: TLS without certificate verification (explicit opt-in)
 *
 * An unrecognized value throws rather than silently downgrading to plaintext.
 * Pin a private CA with `ssl-ca=<path>` (required for `verify_ca`); for the
 * hostname-verified modes, adding the CA to Node's trust store
 * (e.g. NODE_EXTRA_CA_CERTS) also works, though it extends the store rather
 * than pinning.
 */
function extractSslMode(connectionString) {
  const queryIndex = connectionString.indexOf("?");
  if (queryIndex === -1) {
    return { connectionString, ssl: undefined };
  }
  const base = connectionString.slice(0, queryIndex);
  const retained = [];
  let sslMode;
  let sslCaPath;
  for (const param of connectionString.slice(queryIndex + 1).split("&")) {
    const eq = param.indexOf("=");
    const key = (eq === -1 ? param : param.slice(0, eq)).toLowerCase();
    if (
      eq !== -1 &&
      (key === "ssl-mode" || key === "ssl_mode" || key === "sslmode")
    ) {
      sslMode = param.slice(eq + 1).toLowerCase();
    } else if (
      eq !== -1 &&
      (key === "ssl-ca" || key === "ssl_ca" || key === "sslca")
    ) {
      sslCaPath = decodeURIComponent(param.slice(eq + 1));
    } else {
      retained.push(param);
    }
  }
  if (sslMode === undefined && sslCaPath === undefined) {
    return { connectionString, ssl: undefined };
  }
  const rebuilt = retained.length ? `${base}?${retained.join("&")}` : base;
  if (sslMode === undefined) {
    // ssl-ca alone is stripped (mysql2 would reject it as an unknown option)
    // but has no effect without an ssl-mode.
    return { connectionString: rebuilt, ssl: undefined };
  }
  const ca =
    sslCaPath === undefined
      ? undefined
      : require("fs").readFileSync(sslCaPath).toString();
  return { connectionString: rebuilt, ssl: sslOptionForMode(sslMode, ca) };
}

function sslOptionForMode(mode, ca) {
  switch (mode) {
    case "disabled":
    case "disable":
      return undefined;
    case "preferred":
    case "prefer":
    case "required":
    case "require":
    case "verify_identity":
    case "verify-identity":
    case "verifyidentity":
    case "verify-full":
    case "verify_full":
      // mysql2 checks the hostname only when verifyIdentity is set;
      // rejectUnauthorized alone verifies just the chain.
      return {
        rejectUnauthorized: true,
        verifyIdentity: true,
        ...(ca !== undefined && { ca }),
      };
    case "verify_ca":
    case "verify-ca":
    case "verifyca":
      // Without a pinned CA, chain-only verification accepts a certificate
      // from any trusted CA for any host, which authenticates nothing.
      if (ca === undefined) {
        throw new StorageError(
          "ssl-mode=verify_ca requires ssl-ca=<path>; supply the CA to pin, " +
            "or use ssl-mode=required / verify_identity for " +
            "hostname-verified TLS"
        );
      }
      return { rejectUnauthorized: true, ca };
    case "no-verify":
    case "no_verify":
    case "noverify":
      return { rejectUnauthorized: false };
    default:
      throw new StorageError(
        `Unrecognized ssl-mode value \`${mode}\`; expected one of: ` +
          "disabled, preferred, required, verify_ca, verify_identity, no-verify"
      );
  }
}

/**
 * Create a mysql2 pool from a config object.
 * The returned pool can be shared across multiple store implementations.
 */
function createMysqlPool(config) {
  const { connectionString, ssl } = extractSslMode(config.connectionString);
  return mysql.createPool({
    uri: connectionString,
    ...(ssl !== undefined && { ssl }),
    connectionLimit: config.maxPoolSize,
    connectTimeout: (config.createTimeoutSecs || 0) * 1000 || 10000,
    idleTimeout: (config.recycleTimeoutSecs || 0) * 1000 || 10000,
    waitForConnections: true,
    // Serialize JS `Date` parameters as UTC strings rather than host-local
    // time. Paired with explicit `UTC_TIMESTAMP(6)` on the server side, this
    // keeps timestamp comparisons consistent regardless of the host TZ.
    timezone: "Z",
  });
}

/**
 * Create a MysqlStorage instance from an existing mysql2 pool.
 *
 * @param {import('mysql2/promise').Pool} pool - An existing connection pool
 * @param {Buffer|Uint8Array} identity - 33-byte tenant identity (secp256k1 pubkey)
 * @param {object} [logger]
 */
async function createMysqlStorageWithPool(
  pool,
  identity,
  logger = null,
  runMigration = true
) {
  const storage = new MysqlStorage(
    pool,
    identity,
    logger,
    runMigration
  );
  await storage.initialize();
  return storage;
}

/**
 * Create a MysqlStorage instance from a config object.
 * Use defaultMysqlStorageConfig to create a config with sensible defaults.
 *
 * @param {object} config - MySQL storage config
 * @param {Buffer|Uint8Array} identity - 33-byte tenant identity (secp256k1 pubkey)
 * @param {object} [logger]
 */
async function createMysqlStorage(config, identity, logger = null) {
  const pool = createMysqlPool(config);
  return createMysqlStorageWithPool(
    pool,
    identity,
    logger,
    config.runMigration !== false
  );
}

module.exports = {
  MysqlStorage,
  createMysqlStorage,
  createMysqlPool,
  createMysqlStorageWithPool,
  defaultMysqlStorageConfig,
  StorageError,
};
