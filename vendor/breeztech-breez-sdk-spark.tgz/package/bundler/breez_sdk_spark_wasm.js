/* @ts-self-types="./breez_sdk_spark_wasm.d.ts" */
import * as wasm from "./breez_sdk_spark_wasm_bg.wasm";
import { __wbg_set_wasm } from "./breez_sdk_spark_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    BitcoinChainServiceHandle, BreezSdk, DefaultCpfpSigner, DefaultSessionStore, ExternalBreezSignerHandle, ExternalSigners, ExternalSigningSignerHandle, ExternalSparkSignerHandle, IntoUnderlyingByteSource, IntoUnderlyingSink, IntoUnderlyingSource, PasskeyClient, PasskeyLabels, SdkBuilder, SigningOnlyExternalSigners, TokenIssuer, WasmSdkContext, WasmStorageConfig, connect, connectWithSigner, connectWithSigningOnlySigner, createTurnkeySigner, createTurnkeySigningOnlySigner, defaultConfig, defaultExternalSigners, defaultExternalSignersFromSeed, defaultMysqlStorageConfig, defaultPostgresStorageConfig, defaultServerConfig, defaultSessionStore, defaultStorage, getSparkStatus, initLogging, mysqlStorage, newRestChainService, newSharedSdkContext, parseSparkConfig, postgresStorage, singleKeyCpfpSigner, start, task_worker_entry_point
} from "./breez_sdk_spark_wasm_bg.js";
