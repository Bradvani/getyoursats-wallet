# PR 43 final browser CI evidence

Both selected browser workflows completed successfully for candidate `f912253d7a618f7fdc361e8221d37b6962b7eb8e`, tree `0437b489e8626b948bdbd7a54fb3ecaade080024`. This is browser CI evidence, not production or real-funds approval.

## Source and execution scope

- The [release security matrix](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40477235355) checked out the candidate head directly. All three full logs and uploaded JSON reports identify that exact commit.
- The [broad browser smoke job](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40477241102/job/122098388270) checked out GitHub PR merge commit `cf1797d0420cd3d1b4ad8135efd5cf4df2723181`. Its Git tree equals the candidate tree. The completed checkout log and SDK CAS JSON independently identify that merge commit.
- This reviewer retrieved completed GitHub metadata, logs and artifacts, then parsed and hashed their bytes offline. No browser, SDK, wallet, provider, profile or test operation was run by this reviewer.

## Recorded case outcomes

| Workflow and stage | Chromium | Firefox | WebKit | Recorded total |
| --- | ---: | ---: | ---: | ---: |
| Security preview matrix | 7 | 7 | 7 | 21 |
| Read-only rollback matrix | 9 | 9 | 9 | 27 |
| Smoke: built-artifact boundaries | 3 | 3 | 3 | 9 |
| Smoke: installed SDK storage CAS | 9 | 9 | 9 | 27 |
| Smoke: wallet and site journeys | 138 | Not selected | Not selected | 138 |
| Smoke: navigation and motion | Not selected | Combined report | Combined report | 164 |

The last smoke invocation selected Firefox and WebKit and emitted only an aggregate **164 passed** result. No per-project JSON was uploaded for that invocation, so this receipt does not assert an individually reported split. The matrix totals **48** executions and smoke totals **338**, or **386** executions across these selected stages. Repeated cases across engines are not distinct security findings.

All matrix JSON cases and all 27 CAS JSON cases passed on their first attempt, with zero skips, flaky results, unexpected results or report errors. The remaining smoke log reports 9, 138 and 164 passed, with no failure, retry, flaky or skipped summary. The broad smoke configuration permits retries, but none are recorded in this completed log.

The three CAS adapter attestations identify installed SDK adapter SHA256 `1e9be66757efedb89624faebaf4e6e176ce2c3bb5be2b3cc492bbaeac7fc1349` (101819 bytes), matching the exact-head manifest. This checks the recorded adapter identity; it is not a fresh SDK execution by the reviewer.

## Retained evidence

- [Machine-readable receipt](receipt.json), [matrix report cross-check](matrix-summary.json) and [PR checkout metadata](pr-checkout-metadata.json).
- Complete [matrix run](matrix-final-run.json), [matrix jobs](matrix-final-jobs.json), [smoke run](smoke-final-run.json) and [smoke jobs](smoke-final-jobs.json) snapshots.
- Three complete matrix ZIPs, their JSON reports and the complete smoke SDK CAS JSON under `artifacts/` and `reports/`. ZIP digests match GitHub artifact metadata.
- Four complete decoded GitHub job logs under `logs/`, losslessly compressed with deterministic gzip. [Original UTF-8 and compressed hashes](log-hashes.json) retain byte provenance. These are decoded API logs, not claims of original HTTP response-byte identity.
- The smoke artifact is 20,221,546 bytes, SHA256 `ae540cec603767e14f06c7b7cf866992a462938df642e7eeb2ccdef01d3ba205`, GitHub artifact ID `12722455645`. Its full ZIP remains outside this modest evidence directory at `/tmp/gys-pr43-final-smoke-artifact.zip`. The [complete member inventory](smoke-artifact-inventory.json) hashes all 173 regular members. The single CAS JSON is copied here; 172 screenshots remain only in the ZIP and were not visually reviewed. No error-context files were present.

## Limits

These successful browser jobs do not imply that every PR check passed. Code-scanning status and broader release approval are outside this receipt. Fixture and local-artifact checks do not establish deployed provider compatibility, production cutover, funds safety, physical-device or native hardware acceptance, or a qualified independent audit. The read-only rollback manifest explicitly disables signing, mutations, network connections and funds. No source, workflow, remote ref, setting or deployment was changed, and no CI rerun was requested. Later source heads require their own evidence.
