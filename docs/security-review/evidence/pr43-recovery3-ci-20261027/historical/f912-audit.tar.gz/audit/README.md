# PR43 final audit checks, 27 October 2026

Exact head: `f912253d7a618f7fdc361e8221d37b6962b7eb8e`.

**CodeQL findings verdict: FAILURE, one high-severity alert.** The analyzer workflow/job succeeded; that is not a clean analysis verdict. The individual alert rule/file is unavailable through the exposed connector, whose URL allowlist rejects the check-detail and annotation endpoints. The complete separate check output is retained in `receipt.json` and the original final check listing. The large-diff warning leaves introduction attribution uncertain; it does not clear the finding.

**Dependency audit: zero advisories in both all-dependency and npm omit-dev scopes.** The completed job printed all severity totals and explicitly rejected registry errors or nonzero totals. Full audit JSON is in the linked GitHub artifact; its archive was not independently downloaded. The complete original decoded job logs and check/status JSON are retained as lossless gzip, with original and compressed SHA-256 digests in `receipt.json`. A separately normalized dependency log has its transformation and hash recorded.

No source, ref, policy or production change was made. These are source-specific CI observations, not release approval.
