# PR 43 c651 browser CI evidence

**INCOMPLETE: smoke succeeded; the security matrix was cancelled before WebKit tests ran.** Candidate `c6518cc695c82ae110d16a43c96f2c5c6548ebbd`, tree `61f993c61a583a0f467039396bfde726e5cbdf20`. No result from the earlier f912 candidate is used to fill the missing coverage.

## Recorded outcomes

| Workflow and stage | Chromium | Firefox | WebKit | Passing executions |
| --- | ---: | ---: | ---: | ---: |
| Security preview matrix | 7 | 7 | Not run | 14 |
| Read-only rollback matrix | 9 | 9 | Not run | 18 |
| Smoke: built-artifact boundaries | 3 | 3 | 3 | 9 |
| Smoke: installed SDK storage CAS | 9 | 9 | 9 | 27 |
| Smoke: wallet and site journeys | 138 | Not selected | Not selected | 138 |
| Smoke: navigation and motion | Not selected | Combined report | Combined report | 164 |

[Smoke run 40483787963](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40483787963) completed **SUCCESS** at 10:01:22 UTC with **338** passing executions. Its actual checkout was merge commit `a922ee9110d5b3b9e3ee0822654673813a34a52b`, whose tree exactly equals the candidate tree. Both the completed checkout log and CAS report identify that merge. The final navigation invocation emitted only the combined **164 passed** count for Firefox/WebKit; no separate per-project count is asserted.

[Matrix run 40483780128](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40483780128) completed **CANCELLED**. Chromium and Firefox directly checked out the candidate and each passed 7 security plus 9 rollback cases, with no retries, skips, flaky results or report errors. The WebKit job also checked out the candidate but executed **zero cases**: both test stages were skipped after installation timed out. The **32** completed matrix executions are retained as partial evidence. They do not make the matrix pass.

## Confirmed WebKit setup timeout

[WebKit job 122120362240](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40483780128/job/122120362240) ran from 09:50:02 to 10:10:20 UTC. Its dependency installation step ran 09:50:20 to 10:10:17. The exact [public check annotations](webkit-check-annotations.json) state: **“The job has exceeded the maximum execution time of 20m0s”.** The supplied annotation file was copied byte-for-byte; SHA256 `62cac15a1ac75a825fe73eafd2e701000097401fdd1a38db8fed14de30f75b9e`.

The runner used Ubuntu 24.04.5 LTS, image `ubuntu-24.04` version `20261012.334.1`, in Azure westus3. Apt planned 117 MB of archives and 181 newly installed packages through `http://azure.archive.ubuntu.com/ubuntu`. Package indexes fetched 12.6 MB in one second, while later package retrieval entries advanced slowly: the 8,998 kB `libcodec2-1.2` entry was followed by the next package 193.566 seconds later; the 5,851 kB `libavcodec60` entry was followed by the next 123.412 seconds later. These are observed intervals between log entries, not independent throughput measurements.

The last package entry was `libflite1` (13.6 MB) at 10:10:09; the operation was cancelled at 10:10:17. The uploader reported that no evidence files existed. The complete log contains no browser assertion failure, explicit HTTP error or TLS failure. This is a confirmed job-budget timeout during OS dependency downloads; it supplies no WebKit matrix test verdict. The annotations also preserve the Ubuntu 26 migration notice for `ubuntu-latest` and the existing Node action warning. See [the detailed cancellation record](webkit-cancellation.json) and [complete compressed log](logs/matrix-webkit.log.gz).

## Evidence and provenance

- [Machine-readable final receipt](receipt.json), [matrix report cross-check](matrix-summary.json), [CAS cross-check](smoke-cas-summary.json) and [PR checkout metadata](pr-checkout-metadata.json).
- Complete [matrix run](matrix-final-run.json), [matrix jobs](matrix-final-jobs.json), [smoke run](smoke-final-run.json) and [smoke jobs](smoke-final-jobs.json) snapshots.
- Two complete matrix report ZIPs and all report JSON. Their digests match GitHub artifact metadata. The CAS report confirms 9 first-attempt passes per engine and installed adapter SHA256 `1e9be66757efedb89624faebaf4e6e176ce2c3bb5be2b3cc492bbaeac7fc1349` (101,819 bytes), matching the exact-head manifest. This is a check of recorded CI identity, not a fresh SDK execution by this reviewer.
- Four complete decoded job logs under `logs/`, compressed losslessly with original/compressed [byte hashes](log-hashes.json). Installation delays, cancellation and warnings remain intact. These are decoded API logs, not original HTTP response-byte claims.
- The smoke ZIP is 19,580,917 bytes, SHA256 `8c6cfd32860eb495a3d6b33fcc3abbd5cee3ced4ae5b25c428c7b8efe5f4a291`, GitHub artifact ID `12725225758`. It remains outside this modest evidence directory at `/tmp/gys-pr43-c651-smoke-artifact.zip`. [Every member is hashed](smoke-artifact-inventory.json); the CAS JSON is retained here. The other 172 members are screenshots, retained only in the ZIP and not visually reviewed. No error-context files were present.
- The [interim smoke outcome](smoke-outcome.md) and its JSON preserve the earlier log-only snapshot at `2026-10-27T10:02:44.329934+00:00`. Its pending-matrix wording is historical and is superseded by this final receipt.

## Limits

There are **370 passing case executions** across these selected completed stages, with WebKit matrix coverage still missing. Counts across engines are not unique vulnerabilities or independent audits. No prior-head result transfers to this candidate, and no result transfers automatically to later source changes.

This reviewer performed read-only CI retrieval and offline byte/report checks. No SDK, browser, provider, wallet, profile or test operation was run, no source/ref/setting/deployment changed, and no rerun was requested. These results do not establish all-PR-check success, provider compatibility, production cutover, funds safety, physical-device/native-hardware acceptance or qualified independent release approval.
