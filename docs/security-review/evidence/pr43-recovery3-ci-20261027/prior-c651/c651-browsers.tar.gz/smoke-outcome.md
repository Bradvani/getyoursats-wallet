# c651 PR 43 smoke outcome

[Run 40483787963](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40483787963), [job 122120388016](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40483787963/job/122120388016), completed **SUCCESS**. This small receipt precedes the larger uploaded-artifact cross-check.

- Candidate head: `c6518cc695c82ae110d16a43c96f2c5c6548ebbd`.
- Candidate tree: `61f993c61a583a0f467039396bfde726e5cbdf20`.
- Actual checkout in the completed log: PR merge `a922ee9110d5b3b9e3ee0822654673813a34a52b`. GitHub commit metadata confirms the merge has exactly the candidate tree.
- **338 passing executions:** 9 built-artifact cases (3 per engine), 27 SDK CAS cases (9 per engine), 138 Chromium journeys, and 164 Firefox/WebKit navigation cases combined. The log provides only the combined last-stage total.
- No failure, retry, flaky or skipped summary appears in the complete log. All original installation output and warnings are retained in [the compressed log](logs/smoke.log.gz); [original/compressed hashes](log-hashes.json) preserve byte provenance.

The matrix is still pending: Chromium and Firefox each have verified 7 security plus 9 rollback passes; WebKit remains in installation. This document does not mark the matrix or all PR checks as passed. The larger smoke artifact has not yet been downloaded or independently cross-checked.

[Machine-readable outcome](smoke-outcome.json). No SDK, browser, provider, wallet, profile or test operation was executed by this reviewer, and no source, ref or production setting was changed. This is not production, funded-operation or independent-audit approval.
