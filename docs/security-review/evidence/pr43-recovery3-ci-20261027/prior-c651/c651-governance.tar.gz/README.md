# Deployment and governance context, 27 October 2026

This directory preserves new unauthenticated public GET observations, with normal TLS verification. Original response bodies are unchanged. `receipt.json` records actual request/receipt times, response dates, hashes and narrowly scoped interpreted fields. These replace no earlier observations and are not release approval.

The rulesets list describes only that endpoint. No classic branch-protection configuration was inspected, and no general absence-of-protection claim is made. The PR merge-commit metadata is not evidence that an open PR has merged. No browser, wallet initialization, credentials, source/ref mutation or policy/deployment change was used.
