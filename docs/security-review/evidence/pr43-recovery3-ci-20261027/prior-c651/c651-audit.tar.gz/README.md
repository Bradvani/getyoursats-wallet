# PR43 corrected-head audit checks, 27 October 2026

Exact head: `c6518cc695c82ae110d16a43c96f2c5c6548ebbd`.

**CodeQL analyzer and separate findings check both succeeded.** The exact findings title is “No new alerts in code changed by this pull request”; the check has zero annotations. This is not a statement that the repository has zero historical alerts. The analyzer’s 300-file/full-diff warning is retained.

**Dependency evidence reports zero advisories at every severity in both all-dependency and npm omit-dev scopes.** The completed job’s explicit registry-error and zero-total checks passed. The linked GitHub artifact contains the two full audit JSON reports; its ZIP digest is reported by Actions and was not independently rehashed here.

`receipt.json` binds the exact head, completed jobs, separate analysis check, totals and original evidence hashes. Complete decoded logs/status text is preserved as lossless gzip; dedicated structured wrapper responses are marked as reserialized. The earlier f912 high-severity result remains in its separate evidence directory. Nothing was suppressed or overwritten.

No source, ref, policy, retry, wallet or production change was made. These checks do not clear the remaining real-funds release gates.
