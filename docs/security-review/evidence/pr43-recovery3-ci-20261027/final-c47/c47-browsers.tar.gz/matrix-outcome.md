# c47 PR 43 matrix outcome

[Run 40486808144](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40486808144) completed **SUCCESS** directly on `c47ffeda0550f08e3cda994bba06c9745adbdc3a`. All three complete logs and JSON reports identify this checkout.

| Engine | Security preview | Read-only rollback | Total | Dependency installation | Apt package retrieval |
| --- | ---: | ---: | ---: | ---: | --- |
| Chromium | 7 | 9 | 16 | 25 seconds | 25.9 MB in 4 seconds |
| Firefox | 7 | 9 | 16 | 28 seconds | 51.6 MB in 9 seconds |
| WebKit | 7 | 9 | 16 | 57 seconds | 117 MB in 24 seconds |

All **48 cases** passed on the first attempt: no retries, skips, flaky results, unexpected results or report errors. The uploaded ZIP digests match GitHub metadata. These are new c47 executions; earlier candidate results are not reused.

All three official-HTTPS archive steps succeeded and logged the actual replacement in `/etc/apt/apt-mirrors.txt`. Subsequent package retrieval used `https://archive.ubuntu.com/ubuntu`; no retrieval entries used the previous Azure archive address. Each runner used Ubuntu 24.04.5 LTS and `ubuntu-24.04` image version `20261012.334.1`. The download timings above are the actual apt summaries, while full dependency-installation durations come from completed step timestamps. They are observations of this run, not a general performance guarantee.

[Matrix report cross-check](matrix-summary.json), [mirror and installation evidence](mirror-installation-evidence.json), [run metadata](matrix-final-run.json), [job metadata](matrix-final-jobs.json), and [complete decoded-log hashes](log-hashes.json) are retained. Logs are losslessly compressed and preserve original installation output and warnings.

This receipt covers the matrix only. It does not establish all-PR-check success, production clearance, provider compatibility, physical-device or independent-audit acceptance. No source, workflow, ref, mirror, deployment or CI run was changed by this reviewer.
