# PR 43 c47 browser CI evidence

**Both assigned browser workflows succeeded.** Candidate `c47ffeda0550f08e3cda994bba06c9745adbdc3a`, tree `8f18bfbcec61c14b8a48b78359fd8686f26ec60b`. These are fresh c47 results; no earlier-candidate pass is substituted. The PR was still open, draft and unmerged at the final metadata read.

## Source and recorded outcomes

[Matrix run 40486808144](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40486808144) checked out the candidate head directly. [Smoke run 40486813574](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40486813574) checked out PR merge `fc52e5025b061334d4c5127275ba20ca27954ff6`. Its tree exactly equals the candidate tree, and the actual checkout is confirmed by both the completed log and uploaded CAS JSON.

| Workflow and stage | Chromium | Firefox | WebKit | Passing executions |
| --- | ---: | ---: | ---: | ---: |
| Security preview matrix | 7 | 7 | 7 | 21 |
| Read-only rollback matrix | 9 | 9 | 9 | 27 |
| Smoke: built-artifact boundaries | 3 | 3 | 3 | 9 |
| Smoke: installed SDK storage CAS | 9 | 9 | 9 | 27 |
| Smoke: wallet and site journeys | 138 | Not selected | Not selected | 138 |
| Smoke: navigation and motion | Not selected | Combined report | Combined report | 164 |

The matrix passed **48** cases; smoke passed **338**, finishing at **10:23:48 UTC**. The last smoke invocation emits only a combined **164 passed** result for Firefox/WebKit, so no separately reported per-engine split is asserted. The **386** total counts executions across stages and engines, not unique vulnerabilities or independent reviews.

Every matrix JSON case and all 27 CAS JSON cases passed on the first attempt, with zero retries, skips, flaky results, unexpected results or report errors. The remaining smoke log records 9, 138 and 164 passed without a failure, retry, flaky or skipped summary.

## Actual matrix mirror and installation evidence

All three `Use the official HTTPS Ubuntu archive` steps completed successfully. Each log contains the actual update to `/etc/apt/apt-mirrors.txt` followed by retrieval through `https://archive.ubuntu.com/ubuntu`. No retrieval entry uses the former Azure archive URL. All three runners used Ubuntu 24.04.5 LTS, `ubuntu-24.04` image version `20261012.334.1`.

| Matrix engine | Complete dependency-install step | Apt package-download summary |
| --- | ---: | --- |
| Chromium | 25 seconds | 25.9 MB in 4 seconds (7051 kB/s) |
| Firefox | 28 seconds | 51.6 MB in 9 seconds (5986 kB/s) |
| WebKit | 57 seconds | 117 MB in 24 seconds (4775 kB/s) |

These are the actual completed-step timestamps and apt summaries for these jobs, not a general performance guarantee. The [full mirror and installation record](mirror-installation-evidence.json) preserves exact output lines. Smoke used its unchanged installer step, which completed successfully in 41 seconds. Installation output and warnings remain in all four complete logs. The earlier c651 timeout evidence remains separate and unchanged.

## Retained reports and byte provenance

- [Machine-readable final receipt](receipt.json), [matrix cross-check](matrix-summary.json), [CAS cross-check](smoke-cas-summary.json), [checkout metadata](pr-checkout-metadata.json), and [final PR status](pr-final-status.json).
- Complete [matrix run](matrix-final-run.json), [matrix jobs](matrix-final-jobs.json), [smoke run](smoke-final-run.json) and [smoke jobs](smoke-final-jobs.json) metadata.
- Three complete matrix ZIPs and all original report JSON under `artifacts/` and `reports/`. Every ZIP digest matches GitHub artifact metadata. The CAS report identifies installed adapter SHA256 `1e9be66757efedb89624faebaf4e6e176ce2c3bb5be2b3cc492bbaeac7fc1349` (101,819 bytes), matching the exact-head manifest. That is a recorded CI attestation checked against source metadata, not a fresh SDK execution by the reviewer.
- Four complete decoded GitHub job logs, losslessly compressed under `logs/`. [Original UTF-8 and compressed hashes](log-hashes.json) preserve provenance. These are decoded API logs, not claims of original HTTP response-byte identity.
- Smoke artifact `12725398692` is 19,538,599 bytes, SHA256 `ace6a20f677fe1f22e662321313177eac8ebe5df8552d80460021aa406cc8c4e`. The original ZIP remains outside this modest evidence directory at `/tmp/gys-pr43-c47-smoke-artifact.zip`. Its [complete member inventory](smoke-artifact-inventory.json) hashes all 173 regular members. The CAS JSON is retained here; 172 screenshots remain only in the ZIP and were not visually reviewed. No error-context files were present.
- Short [matrix](matrix-outcome.md) and [log-derived smoke](smoke-outcome.md) outcome receipts were provided before final artifact assembly.

## Limits

This receipt covers the assigned browser workflows. It does not establish every PR check, deployed provider compatibility, production cutover, funds safety, physical-device/native-hardware acceptance or qualified independent release approval. The read-only rollback manifest explicitly disables signing, mutation, network connections and funds.

The reviewer performed read-only CI retrieval and offline byte/report checks. No SDK, browser, wallet, provider, profile or test operation was executed; no source, workflow, ref, mirror, setting, deployment or CI run changed; and no retry was requested. Prior evidence directories were left untouched. Later source changes require their own evidence.
