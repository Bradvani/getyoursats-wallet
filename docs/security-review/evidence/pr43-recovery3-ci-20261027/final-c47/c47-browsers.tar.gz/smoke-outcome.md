# c47 PR 43 smoke outcome

[Run 40486813574](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40486813574), [job 122130541321](https://github.com/Bradvani/getyoursats-wallet/actions/runs/40486813574/job/122130541321), completed **SUCCESS** at `2026-10-27T10:23:48Z`. This receipt records the complete job log.

- Candidate: `c47ffeda0550f08e3cda994bba06c9745adbdc3a`, tree `8f18bfbcec61c14b8a48b78359fd8686f26ec60b`.
- Actual checkout: PR merge `fc52e5025b061334d4c5127275ba20ca27954ff6`. GitHub commit metadata confirms exactly the candidate tree.
- **338 passing executions:** 9 built-artifact cases (3 per engine), 27 SDK CAS cases (9 per engine), 138 Chromium journeys, and 164 Firefox/WebKit navigation cases combined. The last invocation emits only its combined total.
- No failure, retry, flaky or skipped summary appears. Original installation output and warnings remain in the [complete compressed log](logs/smoke.log.gz); [byte hashes](log-hashes.json) preserve provenance.

[Machine-readable log outcome](smoke-outcome.json). This receipt does not claim all-PR-check, provider, production, funds, physical-device or independent-audit acceptance. No SDK/browser/provider/profile/test operation or source/ref/deployment change was performed by this reviewer.
