# c47 CodeQL and dependency evidence

This directory retains fresh evidence for candidate `c47ffeda0550f08e3cda994bba06c9745adbdc3a`, tree `8f18bfbcec61c14b8a48b78359fd8686f26ec60b`.

CodeQL run 40486813535 completed successfully. Analyzer job 122130541293 and separate GitHub Advanced Security findings check 122130969914 both succeeded. The findings title is **“No new alerts in code changed by this pull request”**, with zero annotations. The completed analyzer still reports the 300-changed-file diff limit, fallback from overlay mode and skipped diff-informed stage. This is not a repository-wide zero-alert finding.

The analyzer's actual PR merge checkout `fc52e5025b061334d4c5127275ba20ca27954ff6` has the same complete tree as c47, verified through read-only Git commit metadata.

Dependency job 122130525607 succeeded. Its actual `npm audit --json` and `npm audit --omit=dev --json` output each reports zero at every advisory severity. The job checks registry errors and requires an integer total of zero. The omit-dev classification is not a bundle-reachability result. Uploaded artifact metadata is reported by the log; the ZIP was not separately downloaded.

All `.gz` files contain complete retained source bytes, compressed losslessly without sanitization or newline changes. `receipt.json` specifies which source responses were raw JSON bodies, which were dedicated-wrapper JSON serialization, and original/compressed digests. `SHA256SUMS.json` covers each published file except itself.

Previous f912 and c651 receipts remain separate. No retries or remote mutations were performed. This evidence is not qualified independent approval, production promotion or real-funds clearance.
